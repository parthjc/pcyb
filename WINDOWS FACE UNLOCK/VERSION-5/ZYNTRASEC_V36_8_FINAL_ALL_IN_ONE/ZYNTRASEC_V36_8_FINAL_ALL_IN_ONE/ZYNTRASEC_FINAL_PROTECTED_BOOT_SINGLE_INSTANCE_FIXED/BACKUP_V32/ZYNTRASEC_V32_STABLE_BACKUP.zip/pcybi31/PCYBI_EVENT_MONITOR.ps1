$ErrorActionPreference = 'SilentlyContinue'
$root = Join-Path $env:ProgramData 'PCYBI\System'
$app = Join-Path $root 'PCYBI_LOCKSCREEN.exe'
$launcher = Join-Path $root 'PCYBI_EVENT_RELAUNCH.ps1'
$state = Join-Path $root 'monitor.state'
if (-not (Test-Path $app)) { exit 2 }

function Get-LastId([string]$log,[int]$id) {
    try {
        $e = Get-WinEvent -FilterHashtable @{LogName=$log; Id=$id} -MaxEvents 1
        if ($e) { return [int64]$e.RecordId }
    } catch {}
    return [int64]0
}

# Establish a baseline so old sleep/wake events never trigger immediately at sign-in.
$lastResume = Get-LastId 'System' 1
$lastUnlock = Get-LastId 'Security' 4801
$lastTick = [DateTime]::UtcNow

try { Set-Content -Path $state -Value "resume=$lastResume`nunlock=$lastUnlock`npid=$PID" -Force } catch {}

while ($true) {
    Start-Sleep -Seconds 2
    $resume = Get-LastId 'System' 1
    $unlock = Get-LastId 'Security' 4801
    $trigger = $false
    $reason = ''

    if ($resume -gt $lastResume) {
        $trigger = $true
        $reason = 'RESUME'
        $lastResume = $resume
    }
    if ($unlock -gt $lastUnlock) {
        $trigger = $true
        if ($reason) { $reason += '+UNLOCK' } else { $reason = 'UNLOCK' }
        $lastUnlock = $unlock
    }

    if ($trigger) {
        # Prevent two events from relaunching twice.
        $now = [DateTime]::UtcNow
        if (($now - $lastTick).TotalSeconds -ge 8) {
            $lastTick = $now
            try { Set-Content -Path $state -Value "resume=$lastResume`nunlock=$lastUnlock`ntrigger=$reason`ntime=$now" -Force } catch {}
            try {
                Start-Process -FilePath $launcher -WindowStyle Hidden
            } catch {
                try { Start-Process -FilePath 'powershell.exe' -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`"" -WindowStyle Hidden } catch {}
            }
        }
    }
}
