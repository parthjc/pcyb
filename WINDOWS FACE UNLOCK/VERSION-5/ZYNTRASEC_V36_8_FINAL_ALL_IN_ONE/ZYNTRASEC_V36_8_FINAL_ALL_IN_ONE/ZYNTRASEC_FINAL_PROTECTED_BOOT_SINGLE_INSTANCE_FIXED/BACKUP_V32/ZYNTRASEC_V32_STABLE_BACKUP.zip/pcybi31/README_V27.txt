V27 FULL CLEAN AUTO INSTALL

1. Run BUILD_PCYBI_TWO_STAGE.bat once.
2. Run AUTO_CLEAN_INSTALL.bat as Administrator. It removes old PCYBI processes, startup entries, scheduled tasks, startup shortcuts, ProgramData files, face model/master-password data, then installs only one fresh monitor and one fresh lockscreen.
3. Restart Windows.
4. Run PCYBI_FACE_SETUP.exe again to register face and master password.
5. Use VERIFY_PCYBI_FULL_STATE.bat to verify processes/startup/tasks.

Full cleanup intentionally removes PCYBI authentication data. It does not modify Windows sign-in/Windows Hello.
