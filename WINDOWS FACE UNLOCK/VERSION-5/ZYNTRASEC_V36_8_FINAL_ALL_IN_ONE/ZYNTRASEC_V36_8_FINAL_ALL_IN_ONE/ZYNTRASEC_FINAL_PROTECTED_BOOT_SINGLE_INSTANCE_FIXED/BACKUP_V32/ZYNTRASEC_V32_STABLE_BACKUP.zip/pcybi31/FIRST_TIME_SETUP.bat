@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // FIRST TIME SETUP
set "SRC=%~dp0dist"
set "ROOT=%ProgramData%\PCYBI\System"
set "SETUP=%ROOT%\PCYBI_FACE_SETUP.exe"
if not exist "%SRC%\PCYBI_FACE_SETUP.exe" (echo Build first using BUILD_PCYBI_TWO_STAGE.bat & pause & exit /b 1)
if not exist "%SRC%\PCYBI_LOCKSCREEN.exe" (echo Build first using BUILD_PCYBI_TWO_STAGE.bat & pause & exit /b 1)
if not exist "%ROOT%" mkdir "%ROOT%"
copy /y "%SRC%\PCYBI_FACE_SETUP.exe" "%SETUP%" >nul
copy /y "%SRC%\PCYBI_LOCKSCREEN.exe" "%ROOT%\PCYBI_LOCKSCREEN.exe" >nul
copy /y "%~dp0PCYBI_EVENT_RELAUNCH.ps1" "%ROOT%\PCYBI_EVENT_RELAUNCH.ps1" >nul
attrib +h +s "%ROOT%" >nul 2>&1
attrib +h +s "%ROOT%\PCYBI_FACE_SETUP.exe" >nul 2>&1
attrib +h +s "%ROOT%\PCYBI_LOCKSCREEN.exe" >nul 2>&1
echo Starting first-time face + master-password setup...
start /wait "" "%SETUP%"
echo.
echo PCYBI runtime files are installed in the hidden ProgramData folder.
echo First-time setup window has finished.
echo.
echo Hiding this PCYBI setup folder...
attrib +h +s "%~dp0" >nul 2>&1
echo PCYBI setup folder is now hidden.
echo.
echo To access it later, enable Windows Explorer Hidden items or open its path directly.
timeout /t 3 /nobreak >nul

