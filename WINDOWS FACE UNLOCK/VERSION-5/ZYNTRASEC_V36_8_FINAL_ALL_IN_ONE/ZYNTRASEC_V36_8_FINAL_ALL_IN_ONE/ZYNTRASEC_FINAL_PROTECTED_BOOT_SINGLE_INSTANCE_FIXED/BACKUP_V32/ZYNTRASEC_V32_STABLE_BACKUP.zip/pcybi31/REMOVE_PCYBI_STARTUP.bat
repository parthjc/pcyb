@echo off
setlocal EnableExtensions
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Face Security" /f >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Unregister-ScheduledTask -TaskName 'PCYBI Face Security Events' -Confirm:$false -ErrorAction SilentlyContinue" >nul 2>&1
schtasks /Delete /TN "PCYBI Face Security Events" /F >nul 2>&1
echo PCYBI startup and lock/unlock/resume triggers removed.
pause
endlocal
