@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // TRIGGER DIAGNOSTICS
color 0A

echo.
echo ===============================================
echo   PCYBI // TRIGGER DIAGNOSTICS
echo ===============================================
echo.

echo [1] Scheduled task:
schtasks /query /tn "PCYBI Face Security Events" /v /fo list 2>nul
if errorlevel 1 echo Task not found.

echo.
echo [2] Recent Windows unlock events (4801):
powershell.exe -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='Security';Id=4801} -MaxEvents 8 -ErrorAction SilentlyContinue | Select-Object TimeCreated,Id,Message | Format-List"

echo.
echo [3] Recent Windows lock events (4800):
powershell.exe -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='Security';Id=4800} -MaxEvents 8 -ErrorAction SilentlyContinue | Select-Object TimeCreated,Id,Message | Format-List"

echo.
echo [4] Recent resume events (Power-Troubleshooter 1):
powershell.exe -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-Power-Troubleshooter';Id=1} -MaxEvents 8 -ErrorAction SilentlyContinue | Select-Object TimeCreated,Id,Message | Format-List"

echo.
echo [5] Audit policy (lock/unlock events):
auditpol /get /subcategory:"Other Logon/Logoff Events"
echo.
echo [6] PCYBI process:
tasklist /FI "IMAGENAME eq PCYBI_LOCKSCREEN.exe"
echo.
echo ===============================================
echo Save this window/output if a trigger is not working.
echo ===============================================
pause
endlocal
