@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // BUILD V32

echo.
echo ===============================================
echo   PCYBI V32 // BUILD
 echo ===============================================
echo.

where py >nul 2>&1
if errorlevel 1 (echo ERROR: Python launcher ^(py^) not found. & pause & exit /b 1)

py -3.13 -c "import sys; print('Python:', sys.version)" || (echo ERROR: Python 3.13 not found. & pause & exit /b 1)

REM No .venv activation is required. Use the installed Python 3.13 directly.
py -3.13 -m pip install --only-binary=:all: "numpy==2.1.3" "pyinstaller==6.22.3" "pywinauto==0.6.9" "opencv-contrib-python==4.13.0.92"
if errorlevel 1 goto FAIL

py -3.13 -c "import cv2, numpy; print('NumPy:', numpy.__version__); print('OpenCV:', cv2.__version__); print('Haar:', cv2.data.haarcascades)" || goto FAIL

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist data rmdir /s /q data
mkdir data

py -3.13 -c "import cv2, shutil; shutil.copy2(cv2.data.haarcascades+'haarcascade_frontalface_default.xml','data\\haarcascade_frontalface_default.xml'); shutil.copy2(cv2.data.haarcascades+'haarcascade_eye.xml','data\\haarcascade_eye.xml')" || goto FAIL
if not exist "data\haarcascade_frontalface_default.xml" (echo ERROR: Face Haar cascade not found & goto FAIL)
if not exist "data\haarcascade_eye.xml" (echo ERROR: Eye Haar cascade not found & goto FAIL)

echo.
echo [OK] Haar cascade found.
echo [OK] Building PCYBI_FACE_SETUP.exe...
py -3.13 -m PyInstaller --noconfirm --clean --onefile --windowed --name PCYBI_FACE_SETUP --add-data "data\haarcascade_frontalface_default.xml;data" --add-data "data\haarcascade_eye.xml;data" --add-data "common.py;." --collect-submodules cv2 --collect-submodules pywinauto --collect-submodules comtypes --hidden-import cv2.face PCYBI_FACE_SETUP.py
if errorlevel 1 goto FAIL

echo.
echo [OK] Building PCYBI_EVENT_MONITOR.exe...
py -3.13 -m PyInstaller --noconfirm --clean --onefile --windowed --name PCYBI_EVENT_MONITOR PCYBI_EVENT_MONITOR.py
if errorlevel 1 goto FAIL

if not exist "dist\PCYBI_EVENT_MONITOR.exe" goto FAIL

echo.
echo [OK] Building PCYBI_LOCKSCREEN.exe...
py -3.13 -m PyInstaller --noconfirm --clean --onefile --windowed --name PCYBI_LOCKSCREEN --add-data "data\haarcascade_frontalface_default.xml;data" --add-data "data\haarcascade_eye.xml;data" --add-data "common.py;." --collect-submodules cv2 --collect-submodules pywinauto --collect-submodules comtypes --hidden-import cv2.face PCYBI_LOCKSCREEN.py
if errorlevel 1 goto FAIL

if not exist "dist\PCYBI_LOCKSCREEN.exe" goto FAIL
if not exist "dist\PCYBI_FACE_SETUP.exe" goto FAIL
if not exist "dist\PCYBI_EVENT_MONITOR.exe" goto FAIL

echo.
echo BUILD SUCCESSFUL
 echo Setup: %CD%\dist\PCYBI_FACE_SETUP.exe
 echo Monitor: %CD%\dist\PCYBI_EVENT_MONITOR.exe
 echo Lock:  %CD%\dist\PCYBI_LOCKSCREEN.exe
pause
exit /b 0
:FAIL
echo.
echo BUILD FAILED
pause
exit /b 1
