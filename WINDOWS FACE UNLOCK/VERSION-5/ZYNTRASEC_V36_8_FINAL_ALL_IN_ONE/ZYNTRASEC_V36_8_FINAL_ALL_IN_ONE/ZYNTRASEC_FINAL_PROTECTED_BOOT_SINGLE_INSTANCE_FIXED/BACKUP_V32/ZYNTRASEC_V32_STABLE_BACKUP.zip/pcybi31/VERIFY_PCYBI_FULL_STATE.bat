@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // FINAL STATE CHECK
color 0A

echo ==========================================================
echo PCYBI // FINAL INSTALL STATE CHECK
 echo ==========================================================
echo.

echo [1] Running PCYBI processes
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Get-Process -ErrorAction SilentlyContinue | ? { $_.ProcessName -like 'PCYBI*' }; if($p){$p|select ProcessName,Id,Path|Format-Table -AutoSize}else{Write-Host 'No PCYBI process running.'}"
echo.

echo [2] Startup entries containing PCYBI
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$paths=@('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'); foreach($p in $paths){ if(Test-Path $p){$x=Get-ItemProperty $p -ErrorAction SilentlyContinue; $x.PSObject.Properties | ? { $_.Name -match 'PCYBI' -or [string]$_.Value -match 'PCYBI' } | % { Write-Host ($p+' :: '+$_.Name+' :: '+$_.Value) } } }"
echo.

echo [3] Scheduled Tasks containing PCYBI
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$t=Get-ScheduledTask -ErrorAction SilentlyContinue | ? { $_.TaskName -match 'PCYBI' -or $_.TaskPath -match 'PCYBI' }; if($t){$t|select TaskName,TaskPath,State|Format-Table -AutoSize}else{Write-Host 'No PCYBI scheduled task.'}"
echo.

echo [4] Installed files
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$r=Join-Path $env:ProgramData 'PCYBI\System'; Write-Host ('Install folder: '+$r); if(Test-Path $r){Get-ChildItem $r -File | select Name,Length,LastWriteTime|Format-Table -AutoSize}else{Write-Host 'Install folder not found.'}"
echo.

echo [5] Startup folder PCYBI files
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$a=@([Environment]::GetFolderPath('Startup'),(Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp')); foreach($d in $a){if(Test-Path $d){Get-ChildItem $d -Force -ErrorAction SilentlyContinue | ? { $_.Name -match 'PCYBI' } | select FullName}}"
echo.
echo ==========================================================
pause
