@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title PCYBI // FULL CLEAN UNINSTALL
color 0A

net session >nul 2>&1
if errorlevel 1 (
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

echo.
echo ===============================================
echo       PCYBI // FULL CLEAN UNINSTALL
 echo ===============================================
echo.
echo This removes PCYBI processes, startup entries,
echo scheduled tasks, installed files, face model,
echo master-password data and PCYBI logs.
echo.
pause

echo [1/7] Stopping ALL PCYBI processes...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^PCYBI_' -or $_.ProcessName -match '^PCYBI$' } | Stop-Process -Force -ErrorAction SilentlyContinue"
taskkill /F /IM PCYBI_EVENT_MONITOR.exe /T >nul 2>&1
taskkill /F /IM PCYBI_LOCKSCREEN.exe /T >nul 2>&1
taskkill /F /IM PCYBI_FACE_SETUP.exe /T >nul 2>&1

echo [2/7] Removing scheduled tasks containing PCYBI...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ts=Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'PCYBI' -or $_.TaskPath -match 'PCYBI' }; foreach($t in $ts){ Unregister-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -Confirm:$false -ErrorAction SilentlyContinue }"

for /f "delims=" %%T in ('schtasks /query /fo csv /nh 2^>nul ^| findstr /I "PCYBI"') do (
  rem Best-effort cleanup for legacy tasks not visible to PowerShell
)


echo [3/7] Removing PCYBI startup Run/RunOnce entries...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$paths=@('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce','HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'); foreach($p in $paths){ if(Test-Path $p){ $props=(Get-ItemProperty $p -ErrorAction SilentlyContinue).PSObject.Properties; foreach($x in $props){ if($x.Name -notmatch '^PS' -and (($x.Name -match 'PCYBI') -or ([string]$x.Value -match 'PCYBI'))){ Remove-ItemProperty -Path $p -Name $x.Name -Force -ErrorAction SilentlyContinue } } } }"


echo [4/7] Removing PCYBI Startup-folder shortcuts...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$dirs=@([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('CommonStartup')); foreach($d in $dirs){ if(Test-Path $d){ Get-ChildItem $d -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'PCYBI' -or $_.FullName -match 'PCYBI' } | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue } }"


echo [5/7] Removing installed PCYBI data and executables...
for %%D in ("%ProgramData%\PCYBI" "%APPDATA%\PCYBI_WINDOWS_CAMERA_APP" "%LOCALAPPDATA%\PCYBI_WINDOWS_CAMERA_APP") do (
  if exist %%~D (
    attrib -h -s -r "%%~D" /s /d >nul 2>&1
    rmdir /s /q "%%~D" >nul 2>&1
  )
)


echo [6/7] Verifying no PCYBI process/startup/task remains...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'PCYBI' }; $r=@(); foreach($h in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce','HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce')){ if(Test-Path $h){ $q=(Get-ItemProperty $h -ErrorAction SilentlyContinue).PSObject.Properties | Where-Object { $_.Name -match 'PCYBI' -or [string]$_.Value -match 'PCYBI' }; $r += $q } }; $t=Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'PCYBI' -or $_.TaskPath -match 'PCYBI' }; Write-Host ('Processes remaining: '+@($p).Count); Write-Host ('Startup entries remaining: '+@($r).Count); Write-Host ('Scheduled tasks remaining: '+@($t).Count)"


echo [7/7] Final cleanup complete.
echo.
echo PCYBI has been fully removed from this Windows user/machine installation.
echo A Windows restart is recommended so Task Manager refreshes its Startup Apps list.
echo.
pause
endlocal
