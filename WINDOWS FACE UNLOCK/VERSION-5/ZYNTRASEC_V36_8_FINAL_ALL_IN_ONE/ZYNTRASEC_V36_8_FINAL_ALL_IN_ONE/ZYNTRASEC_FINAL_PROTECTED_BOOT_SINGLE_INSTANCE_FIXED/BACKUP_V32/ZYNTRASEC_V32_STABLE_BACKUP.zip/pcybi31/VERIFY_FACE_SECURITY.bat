@echo off
setlocal
cd /d "%~dp0"
echo ===== PCYBI V28 FACE SECURITY CHECK =====
python -m py_compile common.py PCYBI_LOCKSCREEN.py PCYBI_FACE_SETUP.py
if errorlevel 1 (echo PYTHON CHECK FAILED & pause & exit /b 1)
echo Python syntax OK.
if exist dist\PCYBI_LOCKSCREEN.exe (echo LockScreen EXE present) else echo LockScreen EXE not built
if exist dist\PCYBI_FACE_SETUP.exe (echo Face Setup EXE present) else echo Face Setup EXE not built
if exist data\haarcascade_eye.xml (echo Eye cascade present) else echo WARNING: data\haarcascade_eye.xml missing
pause
