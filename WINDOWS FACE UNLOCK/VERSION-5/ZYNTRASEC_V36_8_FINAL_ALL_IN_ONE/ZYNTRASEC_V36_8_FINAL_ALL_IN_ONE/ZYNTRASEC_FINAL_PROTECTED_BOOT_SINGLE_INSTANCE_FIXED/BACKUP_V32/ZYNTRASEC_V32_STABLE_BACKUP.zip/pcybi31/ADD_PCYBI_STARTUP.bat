@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // AUTO CLEAN + INSTALL

net session >nul 2>&1
if errorlevel 1 (
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

set "ROOT=%ProgramData%\PCYBI\System"
set "APP=%ROOT%\PCYBI_LOCKSCREEN.exe"
set "MON=%ROOT%\PCYBI_EVENT_MONITOR.exe"

if not exist "%~dp0dist\PCYBI_LOCKSCREEN.exe" (
  echo PCYBI_LOCKSCREEN.exe not found in dist. Run BUILD_PCYBI_TWO_STAGE.bat first.
  pause
  exit /b 1
)
if not exist "%~dp0dist\PCYBI_EVENT_MONITOR.exe" (
  echo PCYBI_EVENT_MONITOR.exe not found in dist. Run BUILD_PCYBI_TWO_STAGE.bat first.
  pause
  exit /b 1
)

if not exist "%ROOT%" mkdir "%ROOT%" >nul 2>&1

echo [1/5] Cleaning old PCYBI processes...
taskkill /F /IM PCYBI_EVENT_MONITOR.exe >nul 2>&1
taskkill /F /IM PCYBI_LOCKSCREEN.exe >nul 2>&1
taskkill /F /IM PCYBI_FACE_SETUP.exe >nul 2>&1

timeout /t 2 /nobreak >nul

echo [2/5] Removing old startup entries and legacy tasks...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Face Security" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Event Monitor" /f >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI" /f >nul 2>&1
schtasks.exe /Delete /TN "PCYBI Face Security" /F >nul 2>&1
schtasks.exe /Delete /TN "PCYBI Face Security Events" /F >nul 2>&1
schtasks.exe /Delete /TN "PCYBI Face Security Setup" /F >nul 2>&1

for /f "tokens=1,*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" 2^>nul ^| findstr /I "PCYBI"') do reg delete "%%A" /f >nul 2>&1

 echo [3/5] Replacing installed EXEs...
copy /y "%~dp0dist\PCYBI_LOCKSCREEN.exe" "%APP%" >nul
copy /y "%~dp0dist\PCYBI_EVENT_MONITOR.exe" "%MON%" >nul

 echo [4/5] Registering one clean startup entry per component...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Face Security" /t REG_SZ /d "\"%APP%\"" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Event Monitor" /t REG_SZ /d "\"%MON%\"" /f >nul

 echo [5/5] Starting exactly one monitor and one lockscreen...
start "" "%MON%"
timeout /t 2 /nobreak >nul
start "" "%APP%"

echo.
echo ===============================================
echo PCYBI AUTO CLEAN + INSTALL COMPLETE
echo ===============================================
echo Old duplicate PCYBI startup/process entries were removed.
echo Face data was preserved.
echo Exactly one monitor and one lockscreen were started.
echo.
echo Restart Windows once after installation.
echo ===============================================
pause
endlocal
