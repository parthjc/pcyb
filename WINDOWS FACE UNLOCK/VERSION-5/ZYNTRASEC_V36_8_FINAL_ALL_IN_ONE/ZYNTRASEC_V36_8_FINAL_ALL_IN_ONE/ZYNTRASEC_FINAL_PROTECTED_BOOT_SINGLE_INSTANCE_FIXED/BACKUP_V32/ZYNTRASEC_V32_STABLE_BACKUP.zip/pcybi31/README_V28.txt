PCYBI V28 — LIVENESS / ANTI-SPOOF UPDATE

This version tightens face matching and adds an open-eyes -> blink -> open-eyes challenge.
A single still photo shown on a phone should not satisfy the liveness sequence.

Important: webcam-only software liveness is not equivalent to hardware-backed Windows Hello/IR depth authentication.
A sophisticated replay/video attack may still defeat software-only checks. For highest assurance, use a Windows Hello-compatible IR/depth camera.
