PCYBI V18 - EVENT XML + SLEEP/WAKE FIX

V18 fixes the malformed Task Scheduler XML seen on some Windows 10/11 systems.
The scheduled task now uses the compatible Task XML schema version 1.2 and is only responsible for workstation SessionUnlock.
Sleep/hibernate resume is handled by the persistent PCYBI Event Monitor, which watches System / Power-Troubleshooter Event ID 1.

Install/repair:
1. Run ADD_PCYBI_STARTUP.bat as Administrator.
2. Restart/sign in once.
3. Test Win+L -> Unlock.
4. Test Sleep -> Wake.
5. If needed, run TEST_SLEEP_TRIGGER.bat.

The installer verifies the scheduled task after registration.
This is an app-level lock and does not replace Windows Secure Sign-in or protect the pre-logon screen.
