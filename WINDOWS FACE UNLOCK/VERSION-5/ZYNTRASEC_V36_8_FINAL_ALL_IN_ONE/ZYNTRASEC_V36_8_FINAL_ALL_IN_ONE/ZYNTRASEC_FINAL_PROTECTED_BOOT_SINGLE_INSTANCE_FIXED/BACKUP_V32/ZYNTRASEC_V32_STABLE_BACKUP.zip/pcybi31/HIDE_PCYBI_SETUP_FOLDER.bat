@echo off
setlocal EnableExtensions
cd /d "%~dp0"
attrib +h +s "%~dp0" >nul 2>&1
echo PCYBI setup folder is now hidden.
echo Path: %~dp0
timeout /t 3 /nobreak >nul
endlocal
