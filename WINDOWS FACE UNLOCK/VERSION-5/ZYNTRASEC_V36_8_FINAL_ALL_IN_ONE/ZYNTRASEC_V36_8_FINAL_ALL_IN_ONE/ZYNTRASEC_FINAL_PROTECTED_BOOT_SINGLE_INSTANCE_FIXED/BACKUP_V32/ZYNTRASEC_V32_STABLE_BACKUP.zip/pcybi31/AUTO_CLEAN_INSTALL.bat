@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title PCYBI // FULL CLEAN + NEW INSTALL
color 0A

net session >nul 2>&1
if errorlevel 1 (
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

if not exist "%~dp0dist\PCYBI_LOCKSCREEN.exe" goto NO_BUILD
if not exist "%~dp0dist\PCYBI_EVENT_MONITOR.exe" goto NO_BUILD
if not exist "%~dp0dist\PCYBI_FACE_SETUP.exe" goto NO_BUILD

echo.
echo ===============================================
echo   PCYBI // FULL CLEAN + NEW INSTALL
 echo ===============================================
echo.
echo [1/6] Full cleanup...
call "%~dp0UNINSTALL_PCYBI_FULL.bat"
if errorlevel 1 exit /b 1

rem Re-enter elevated context after the uninstaller's pause/return.

echo [2/6] Waiting for Windows process handles to release...
timeout /t 2 /nobreak >nul

set "ROOT=%ProgramData%\PCYBI\System"
if not exist "%ROOT%" mkdir "%ROOT%" >nul 2>&1

 echo [3/6] Installing fresh binaries...
copy /y "%~dp0dist\PCYBI_LOCKSCREEN.exe" "%ROOT%\PCYBI_LOCKSCREEN.exe" >nul || goto FAIL
copy /y "%~dp0dist\PCYBI_EVENT_MONITOR.exe" "%ROOT%\PCYBI_EVENT_MONITOR.exe" >nul || goto FAIL
copy /y "%~dp0dist\PCYBI_FACE_SETUP.exe" "%ROOT%\PCYBI_FACE_SETUP.exe" >nul || goto FAIL

 echo [4/6] Registering ONLY one startup entry per component...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Face Security" /t REG_SZ /d "\"%ROOT%\PCYBI_LOCKSCREEN.exe\"" /f >nul || goto FAIL
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Event Monitor" /t REG_SZ /d "\"%ROOT%\PCYBI_EVENT_MONITOR.exe\"" /f >nul || goto FAIL

 echo [5/6] Starting one monitor only...
start "" "%ROOT%\PCYBI_EVENT_MONITOR.exe"
timeout /t 2 /nobreak >nul

 echo [6/6] Installation verification...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=@(Get-Process -Name PCYBI_EVENT_MONITOR,PCYBI_LOCKSCREEN -ErrorAction SilentlyContinue); $r=(Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -ErrorAction SilentlyContinue); Write-Host ('PCYBI processes: '+$p.Count); Write-Host ('Lock startup: '+[bool]($r.'PCYBI Face Security')); Write-Host ('Monitor startup: '+[bool]($r.'PCYBI Event Monitor'))"

echo.
echo ===============================================
echo   PCYBI FULL CLEAN + NEW INSTALL COMPLETE
echo ===============================================
echo Restart Windows once before testing Sleep/Wake.
echo Face/master setup must be run again after full clean.
echo ===============================================
pause
exit /b 0

:NO_BUILD
echo ERROR: Build files are missing from dist\
echo Run BUILD_PCYBI_TWO_STAGE.bat first.
pause
exit /b 1

:FAIL
echo INSTALL FAILED.
pause
exit /b 1
