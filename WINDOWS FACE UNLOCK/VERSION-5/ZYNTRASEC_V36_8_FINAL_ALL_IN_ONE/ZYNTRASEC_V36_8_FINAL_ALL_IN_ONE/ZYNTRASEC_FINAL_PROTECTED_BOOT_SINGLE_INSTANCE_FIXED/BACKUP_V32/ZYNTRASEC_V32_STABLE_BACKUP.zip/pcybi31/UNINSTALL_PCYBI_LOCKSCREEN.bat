@echo off
setlocal
cd /d "%~dp0"
call "%~dp0UNINSTALL_ALL_PCYBI.bat"
endlocal
