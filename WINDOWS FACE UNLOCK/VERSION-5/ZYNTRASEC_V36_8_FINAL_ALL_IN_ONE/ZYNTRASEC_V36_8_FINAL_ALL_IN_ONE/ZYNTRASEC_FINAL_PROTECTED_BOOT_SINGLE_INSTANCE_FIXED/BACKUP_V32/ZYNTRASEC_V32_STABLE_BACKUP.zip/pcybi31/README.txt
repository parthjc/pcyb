PCYBI FACE SECURITY V15

1. Run BUILD_PCYBI_TWO_STAGE.bat.
2. Run FIRST_TIME_SETUP.bat. It sets the Master Password first, then registers 5 face photos.
3. Runtime files and face/password data are stored under the hidden ProgramData\PCYBI folder.
4. Run ADD_PCYBI_STARTUP.bat to enable login startup, or INSTALL_PCYBI_LOCKSCREEN.bat which also installs the login task.
5. REMOVE_PCYBI_STARTUP.bat disables startup without deleting data.
6. UNINSTALL_ALL_PCYBI.bat removes the PCYBI task, hidden PCYBI data, and PCYBI startup shortcuts.

This is an app-level lock after Windows login, not a replacement for Windows secure sign-in.


FIRST-TIME SETUP FOLDER
- FIRST_TIME_SETUP.bat waits for setup to finish and then hides the PCYBI project folder.
- HIDE_PCYBI_SETUP_FOLDER.bat can hide it manually later.
- Hidden does not mean encrypted; an administrator can still access it.

V15 EVENT LOCK: Registry startup entry remains for Task Manager visibility. A separate Scheduled Task named "PCYBI Face Security Events" starts PCYBI at Windows logon and on workstation unlock. The single-instance mutex prevents duplicate PCYBI windows when both startup mechanisms fire. Sleep/Hibernate resume is covered when Windows is subsequently unlocked. This remains an app-level lock, not a replacement for Windows Secure Sign-in/Ctrl+Alt+Del.

V15 fixes: no .venv activation required; Haar cascade copied from cv2.data; PCYBI overlay stays visible while Camera is topmost; startup triggers include logon, SessionUnlock, and Power-Troubleshooter resume.

V15 EVENT LOGIC FIX:
- ADD_PCYBI_STARTUP.bat installs a small relaunch helper into ProgramData\PCYBI\System.
- Startup Apps + SessionUnlock + Power-Troubleshooter Resume all call that helper.
- The helper stops any stale PCYBI_LOCKSCREEN.exe instance and starts a fresh one, so a running instance cannot suppress an unlock/resume relock.
- CHECK_PCYBI_TRIGGERS.bat shows task configuration, unlock/lock events, resume events, and current PCYBI process.


V16 EVENT FIX NOTES
- Scheduled task registration is verified immediately; installer no longer reports success if task creation failed.
- Uses schtasks.exe first, with Register-ScheduledTask as fallback.
- Adds Administrator elevation for reliable installation.
- Enables the Windows audit subcategory used for workstation lock/unlock events 4800/4801.
- Registry Startup entry uses a valid executable path without escaped backslashes.
- REPAIR_PCYBI_EVENTS.bat can reinstall only the event triggers without rebuilding the EXE.


V20 fixes: PCYBI_EVENT_MONITOR.exe is now actually built by BUILD_PCYBI_TWO_STAGE.bat. The previous V21 build checked for the monitor EXE without building it, causing BUILD FAILED after the lockscreen EXE had already completed. Startup voice was also removed because it overlapped with the face-authentication announcement.
