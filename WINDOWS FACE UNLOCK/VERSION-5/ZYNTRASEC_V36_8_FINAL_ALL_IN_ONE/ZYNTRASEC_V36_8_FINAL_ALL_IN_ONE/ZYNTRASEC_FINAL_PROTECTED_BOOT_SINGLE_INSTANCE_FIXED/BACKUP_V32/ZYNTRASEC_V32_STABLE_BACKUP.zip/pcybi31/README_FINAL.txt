PCYBI FINAL ONE-CLICK PACKAGE

1) Right-click 00_FINAL_INSTALL.bat -> Run as administrator.
2) It builds fresh EXEs, removes old PCYBI processes/startup/tasks/data, installs one clean copy, verifies it, and opens Face Setup.
3) Complete face registration and master password setup.
4) Restart Windows once.
5) Test sign-in, Win+L unlock, Sleep/Wake and Hibernate/Wake.

For diagnostics: VERIFY_PCYBI_FULL_STATE.bat and VERIFY_SLEEP_MONITOR.bat.
For full removal: UNINSTALL_PCYBI_FULL.bat.

This is an app-level lock after Windows sign-in; it does not replace Windows Secure Sign-in/Ctrl+Alt+Del.
