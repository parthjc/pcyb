$ErrorActionPreference = 'Stop'
$root = Join-Path $env:ProgramData 'PCYBI\System'
$app = Join-Path $root 'PCYBI_LOCKSCREEN.exe'
$launcher = Join-Path $root 'PCYBI_EVENT_RELAUNCH.ps1'
$task = 'PCYBI Face Security Events'
$taskPath = '\'
if (-not (Test-Path $app)) { throw "PCYBI_LOCKSCREEN.exe not found: $app" }
if (-not (Test-Path $launcher)) { throw "PCYBI_EVENT_RELAUNCH.ps1 not found: $launcher" }
$sid = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
$ps = (Join-Path $PSHOME 'powershell.exe')
$arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`""
$xml = @"
<Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task" version="1.2">
  <RegistrationInfo>
    <Description>PCYBI app-level face lock for workstation unlock. Sleep/hibernate resume is handled by the persistent PCYBI Event Monitor.</Description>
  </RegistrationInfo>
  <Triggers>
    <SessionStateChangeTrigger>
      <Enabled>true</Enabled>
      <StateChange>SessionUnlock</StateChange>
      <UserId>$sid</UserId>
    </SessionStateChangeTrigger>
    <EventTrigger>
      <Enabled>true</Enabled>
      <Subscription><![CDATA[
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name='Microsoft-Windows-Power-Troubleshooter'] and (EventID=1)]]</Select></Query></QueryList>
      ]]></Subscription>
    </EventTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>$sid</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>$ps</Command>
      <Arguments>$arg</Arguments>
      <WorkingDirectory>$root</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"@
$xmlPath = Join-Path $env:TEMP 'PCYBI_FaceSecurityEvents.xml'
Set-Content -Path $xmlPath -Value $xml -Encoding UTF8 -Force

# Register through schtasks.exe for maximum compatibility across Windows 10/11.
# This task is per-user because the UI lockscreen must run in the interactive session.
& schtasks.exe /Create /TN $task /XML $xmlPath /F | Out-Host
if ($LASTEXITCODE -ne 0) {
    # Fallback to the Task Scheduler PowerShell cmdlet.
    Register-ScheduledTask -TaskName $task -Xml $xml -Force | Out-Null
}

# Verify immediately; never report success if the task was not actually created.
$check = & schtasks.exe /Query /TN $task /FO LIST 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "PCYBI scheduled task registration failed. $check"
}
Remove-Item $xmlPath -Force -ErrorAction SilentlyContinue
Write-Host "Installed and verified: $task"
Write-Host "Trigger: SessionUnlock (resume handled by Event Monitor)"
