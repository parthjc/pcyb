@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // UNINSTALL ALL
color 0A

echo.
echo ===============================================
echo        PCYBI // UNINSTALL ALL
echo ===============================================
echo.

echo [1/5] Removing scheduled login/unlock tasks + startup entry...
schtasks /Delete /TN "PCYBI Face Security" /F >nul 2>&1
schtasks /Delete /TN "PCYBI Face Security Events" /F >nul 2>&1
schtasks /Delete /TN "PCYBI Face Security Setup" /F >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Unregister-ScheduledTask -TaskName 'PCYBI Face Security Events' -Confirm:\$false -ErrorAction SilentlyContinue" >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PCYBI Face Security" /f >nul 2>&1

echo [2/5] Stopping PCYBI applications...
taskkill /F /IM PCYBI_LOCKSCREEN.exe >nul 2>&1
taskkill /F /IM PCYBI_FACE_SETUP.exe >nul 2>&1
taskkill /F /IM PCYBI_CAMERA_AUTO.exe >nul 2>&1

echo [3/5] Removing PCYBI registered face + master password data...
if exist "%APPDATA%\PCYBI_WINDOWS_CAMERA_APP" rmdir /s /q "%APPDATA%\PCYBI_WINDOWS_CAMERA_APP"
if exist "%LOCALAPPDATA%\PCYBI_WINDOWS_CAMERA_APP" rmdir /s /q "%LOCALAPPDATA%\PCYBI_WINDOWS_CAMERA_APP"
if exist "%PROGRAMDATA%\PCYBI" (
    attrib -h -s "%PROGRAMDATA%\PCYBI" /s /d >nul 2>&1
    rmdir /s /q "%PROGRAMDATA%\PCYBI"
)

echo [4/5] Removing PCYBI startup shortcuts if present...
if exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PCYBI*.lnk" del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PCYBI*.lnk" >nul 2>&1
if exist "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\PCYBI*.lnk" del /q "%ProgramData%\Microsoft\Windows\Start Menu\Programs\Startup\PCYBI*.lnk" >nul 2>&1

echo [5/5] Done.
echo.
echo PCYBI login task, face model, master-password hash,
echo and PCYBI application data have been removed.
echo.
echo Windows login itself was NOT changed.
echo.
pause
endlocal
