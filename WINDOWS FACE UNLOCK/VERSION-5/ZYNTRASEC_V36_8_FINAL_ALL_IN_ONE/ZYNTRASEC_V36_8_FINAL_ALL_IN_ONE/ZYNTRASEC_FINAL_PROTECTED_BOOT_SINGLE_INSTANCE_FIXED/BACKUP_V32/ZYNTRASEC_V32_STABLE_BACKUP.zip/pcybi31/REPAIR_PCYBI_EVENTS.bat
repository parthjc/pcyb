@echo off
setlocal
cd /d "%~dp0"
title PCYBI // V19 REPAIR HYBRID EVENTS
call "%~dp0ADD_PCYBI_STARTUP.bat"
endlocal
