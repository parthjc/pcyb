PCYBI V20 HYBRID EVENT ARCHITECTURE

- Sign-in: Registry Run startup entry.
- Workstation unlock: native WTS_SESSION_UNLOCK notification.
- Sleep/hibernate resume: native WM_POWERBROADCAST notifications (PBT_APMRESUMEAUTOMATIC / PBT_APMRESUMESUSPEND).
- Existing Windows Power-Troubleshooter Event ID 1 can be used for diagnostics/fallback, but is not required for the primary wake path.
- Old Scheduled Task XML and 4800/4801 audit policy are NOT required.
- PCYBI_EVENT_MONITOR.exe stays resident and launches PCYBI_LOCKSCREEN.exe after unlock/resume with 8-second debounce.
- Voice uses one serialized SpeechSynthesizer process at a time to prevent overlapping/doubled speech.


V20 fixes: PCYBI_EVENT_MONITOR.exe is now actually built by BUILD_PCYBI_TWO_STAGE.bat. The previous V21 build checked for the monitor EXE without building it, causing BUILD FAILED after the lockscreen EXE had already completed. Startup voice was also removed because it overlapped with the face-authentication announcement.
