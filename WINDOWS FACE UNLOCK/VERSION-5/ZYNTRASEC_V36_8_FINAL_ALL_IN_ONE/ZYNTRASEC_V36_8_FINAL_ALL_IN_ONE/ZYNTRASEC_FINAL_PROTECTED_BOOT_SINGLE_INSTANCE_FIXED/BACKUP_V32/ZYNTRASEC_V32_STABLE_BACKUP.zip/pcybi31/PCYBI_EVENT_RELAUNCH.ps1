$ErrorActionPreference='SilentlyContinue'
$app = Join-Path $env:ProgramData 'PCYBI\System\PCYBI_LOCKSCREEN.exe'
$state = Join-Path $env:ProgramData 'PCYBI\System\event-relaunch.lock'
if (-not (Test-Path $app)) { exit 2 }

# Debounce unlock + resume events that can arrive within a few seconds of each other.
try {
    if (Test-Path $state) {
        $age = ((Get-Date) - (Get-Item $state).LastWriteTime).TotalSeconds
        if ($age -lt 8) { exit 0 }
    }
    Set-Content -Path $state -Value ([DateTime]::Now.ToString('o')) -Force
} catch {}

# Replace the old lock session with one fresh session.
Get-Process -Name 'PCYBI_LOCKSCREEN' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 500
Start-Process -FilePath $app -WorkingDirectory (Split-Path $app)
exit 0
