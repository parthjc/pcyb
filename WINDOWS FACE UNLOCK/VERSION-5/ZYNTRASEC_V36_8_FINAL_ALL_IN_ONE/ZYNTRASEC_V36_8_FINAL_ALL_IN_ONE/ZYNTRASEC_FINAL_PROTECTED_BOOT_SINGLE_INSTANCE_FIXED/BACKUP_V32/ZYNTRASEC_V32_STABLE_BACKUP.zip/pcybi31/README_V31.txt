PCYBI V31 - LIVE VIDEO FACE AUTHENTICATION

Uses continuous webcam frames for setup and authentication instead of taking individual Windows Camera photos. Setup guides LEFT -> RIGHT -> CENTER with automatic timed capture. Authentication uses random blink/left/right challenge and multi-frame identity verification. This improves resistance to static photos and simple replay, but no RGB webcam software can guarantee 100% anti-spoofing.

V32 behavior: no mandatory blink/head-turn challenge. Authentication uses continuous live-video frames, repeated face identity matches, and a temporal-motion liveness heuristic. Software-only liveness is not a 100% anti-spoof guarantee.
