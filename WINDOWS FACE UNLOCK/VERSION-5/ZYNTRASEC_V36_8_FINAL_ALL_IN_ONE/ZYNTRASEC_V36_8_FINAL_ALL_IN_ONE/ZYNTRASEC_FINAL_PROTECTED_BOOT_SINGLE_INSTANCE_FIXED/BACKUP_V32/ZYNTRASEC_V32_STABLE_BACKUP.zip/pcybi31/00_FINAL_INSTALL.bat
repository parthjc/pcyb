@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // FINAL ONE-CLICK INSTALL
color 0A

net session >nul 2>&1
if errorlevel 1 (
  echo Requesting Administrator permission...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b 0
)

echo.
echo ==========================================================
echo        PCYBI // FINAL ONE-CLICK CLEAN INSTALL
 echo ==========================================================
echo.
echo This will remove old PCYBI processes, startup entries,
echo scheduled tasks and old PCYBI installation data, then
 echo build/install a fresh copy and open Face Setup.
echo.
choice /C YN /N /M "Continue? [Y/N]: "
if errorlevel 2 exit /b 0

echo.
echo [1/4] Building fresh executables...
call "%~dp0BUILD_PCYBI_TWO_STAGE.bat"
if errorlevel 1 goto FAIL

 echo [2/4] Full cleanup + fresh installation...
call "%~dp0AUTO_CLEAN_INSTALL.bat"
if errorlevel 1 goto FAIL

 echo [3/4] Verifying installation...
call "%~dp0VERIFY_PCYBI_FULL_STATE.bat"
if errorlevel 1 goto FAIL

 echo [4/4] Opening first-time Face + Master Password setup...
timeout /t 2 /nobreak >nul
start "" "%ProgramData%\PCYBI\System\PCYBI_FACE_SETUP.exe"

echo.
echo ==========================================================
echo FINAL INSTALL COMPLETE
echo ==========================================================
echo Complete Face + Master Password setup in the window.
echo Then restart Windows once and test Unlock + Sleep/Wake.
echo ==========================================================
pause
exit /b 0

:FAIL
echo.
echo ==========================================================
echo FINAL INSTALL FAILED
echo Check the message above.
echo ==========================================================
pause
exit /b 1
