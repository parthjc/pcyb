@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PCYBI // INSTALL LOCKSCREEN
set "SRC=%~dp0dist"
set "ROOT=%ProgramData%\PCYBI\System"
set "APP=%ROOT%\PCYBI_LOCKSCREEN.exe"
if not exist "%SRC%\PCYBI_LOCKSCREEN.exe" (echo Build first using BUILD_PCYBI_TWO_STAGE.bat & pause & exit /b 1)
if not exist "%SRC%\PCYBI_FACE_SETUP.exe" (echo Build first using BUILD_PCYBI_TWO_STAGE.bat & pause & exit /b 1)
if not exist "%ROOT%" mkdir "%ROOT%"
copy /y "%SRC%\PCYBI_LOCKSCREEN.exe" "%ROOT%\PCYBI_LOCKSCREEN.exe" >nul
copy /y "%SRC%\PCYBI_FACE_SETUP.exe" "%ROOT%\PCYBI_FACE_SETUP.exe" >nul
attrib +h +s "%ROOT%" >nul 2>&1
attrib +h +s "%ROOT%\PCYBI_LOCKSCREEN.exe" >nul 2>&1
attrib +h +s "%ROOT%\PCYBI_FACE_SETUP.exe" >nul 2>&1
call "%~dp0ADD_PCYBI_STARTUP.bat"
echo LOCKSCREEN INSTALLED IN HIDDEN PCYBI FOLDER.
echo Run FIRST_TIME_SETUP.bat before signing out.
pause
