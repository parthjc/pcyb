@echo off
setlocal
set "ROOT=%ProgramData%\PCYBI\System"
echo ===== PCYBI SLEEP/WAKe MONITOR =====
echo.
echo [1] Monitor process:
tasklist /FI "IMAGENAME eq PCYBI_EVENT_MONITOR.exe"
echo.
echo [2] Recent monitor log:
if exist "%ROOT%\event_monitor.log" (powershell -NoProfile -Command "Get-Content -Path '%ROOT%\event_monitor.log' -Tail 30") else echo Log not found.
echo.
echo [3] Latest Power-Troubleshooter Event 1:
powershell -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-Power-Troubleshooter'; Id=1} -MaxEvents 3 | Select TimeCreated,Id,ProviderName | Format-List"
echo.
pause
