@echo off
setlocal
set "ROOT=%ProgramData%\PCYBI\System"
echo ===============================================
echo PCYBI V19 HYBRID MONITOR TEST
echo ===============================================
echo.
echo [1] Monitor process:
tasklist /FI "IMAGENAME eq PCYBI_EVENT_MONITOR.exe"
echo.
echo [2] Monitor log:
if exist "%ROOT%\event_monitor.log" (type "%ROOT%\event_monitor.log") else (echo Log not found: %ROOT%\event_monitor.log)
echo.
echo [3] Latest Power-Troubleshooter resume events:
powershell.exe -NoProfile -Command "Get-WinEvent -FilterHashtable @{LogName='System'; Id=1} -MaxEvents 5 | Select TimeCreated,Id,ProviderName | Format-List"
echo.
echo [4] Latest PCYBI process:
tasklist /FI "IMAGENAME eq PCYBI_LOCKSCREEN.exe"
echo.
echo ===============================================
pause
endlocal
